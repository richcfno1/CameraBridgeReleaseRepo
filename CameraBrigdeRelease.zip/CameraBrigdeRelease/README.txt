日冕玄学研究所
原作者：RC
特别鸣谢：岚依 PRK PDZ

把文件解压到任何地方，先启动Injector.exe，然后正常启动游戏。
先看教程！

注意：
"CoronaLauncher compatible mode - will not inject into RA3.exe unless launcher exits"不是一个错误！请忽略！